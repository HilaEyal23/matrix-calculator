#include "./mat.h"

typedef double matrix[MAT_SIZE][MAT_SIZE];

struct mat {
	char[] name;
	matix *mat;
} 

void copy_mat(mat *mat1, mat *mat2){
    int i,j;
    for(i=0; i<MAT_SIZE; i++){
        for(j=0; j<MAT_SIZE; j++){
            mat2 -> matrix[i][j] = mat1 -> matrix[i][j];
        }
    }
}

void read_mat(mat *mat1 ,int values[])
{
	int i,j,k=0;
    for(i=0; i<MAT_SIZE; i++){
        for(j=0; j<MAT_SIZE; j++){
            mat1 -> matrix[i][j] = values[k];
            k++;
        }
    }	
}

void print_mat(mat *mat)
{
	int i,j;
    for(i=0; i<MAT_SIZE; i++){
        for(j=0; j<MAT_SIZE]; j++){
            printf("%9.2f", mat -> matrix[i][j]);
        }
        printf("/n");
    }
}

void add_mat(mat *mat1, mat *mat2, mat *mat3)
{
	int i, j;
    matrix tmp[MAT_SIZE][MAT_SIZE];
    mat tmp = {"TMP",&tmp};
        for(i=0; i<MAT_SIZE; i++){
            for(j=0; j<MAT_SIZE; j++){
            tmp.matrix[i][j] = mat1 -> matrix[i][j] + mat2 -> matrix[i][j];
        }
    }
    copy_mat(&tmp,mat3);
    print_mat();
}

void sub_mat(mat *mat1, mat *mat2, mat *mat3)
{
	int i, j;
    matrix tmp[MAT_SIZE][MAT_SIZE];
    mat tmp = {"TMP",&tmp};
    for(i=0; i<MAT_SIZE; i++){
        for(j=0; j<MAT_SIZE; j++){
             tmp.matrix[i][j] = mat1 -> matrix[i][j] - mat2 -> matrix[i][j];
        }
    }
    copy_mat(&tmp,mat3)
}

void mul_mat(mat *mat1, mat *mat2, mat *mat3)
{
	int i, j, sum = 0;
    matrix tmp[MAT_SIZE][MAT_SIZE];
    mat tmp = {"TMP",&tmp};
    for(i=0; i<MAT_SIZE; i++){
        for(j=0; j<MAT_SIZE; j++){
             tmp.matrix[i][j] = mat1 -> matrix[i][j] * mat2 -> matrix[i][j];
        }
    }
    copy_mat(&tmp,mat3)
}

void mul_scalar(mat *mat1, double num, mat *mat2)
{
	int i, j;
    matrix tmp[MAT_SIZE][MAT_SIZE];
    mat tmp = {"TMP",&tmp};
    for(i=0; i<MAT_SIZE; i++){
        for(j=0; j<MAT_SIZE; j++){
             tmp.matrix[i][j] = mat1 -> matrix[i][j]*num;
        }
    }
    copy_mat(&tmp,mat2)
}


void trans_mat(mat *mat1, mat *mat2)
{
	int i, j;
    matrix tmp[MAT_SIZE][MAT_SIZE];
    mat tmp = {"TMP",&tmp};
    for(i=0; i<MAT_SIZE; i++){
        for(j=0; j<MAT_SIZE; j++){
            tmp.matrix[i][j] = mat1 -> matrix[j][i];
        }
    }
    copy_mat(&tmp,mat2)
}

void stop(void)
{
    printf("program stops");
	exit(0);
}